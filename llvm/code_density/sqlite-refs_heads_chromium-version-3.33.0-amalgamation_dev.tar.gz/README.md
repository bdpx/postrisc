**DO NOT EDIT FILES IN THIS DIRECTORY.**

These files are automatically generated from the SQLite originals. If files in
this directory are edited those changes **will** be dropped in subsequent
changes in this projects branch.

See the contents of `chromium/src/third_party/sqlite/scripts` for information
on how these files are built.
